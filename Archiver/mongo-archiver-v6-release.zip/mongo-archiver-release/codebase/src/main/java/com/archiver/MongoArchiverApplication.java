package com.archiver;

import com.archiver.job.ArchiveCronJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@Slf4j
@SpringBootApplication
@EnableScheduling
@RequiredArgsConstructor
public class MongoArchiverApplication implements ApplicationRunner {

    private final ArchiveCronJob archiveCronJob;

    public static void main(String[] args) {
        SpringApplication.run(MongoArchiverApplication.class, args);
    }

    @Override
    public void run(ApplicationArguments args) {
        if (args.containsOption("run-now")) {
            log.info("[MongoArchiverApplication] --run-now: triggering immediate scheduled run");
            archiveCronJob.runNow();
            log.info("[MongoArchiverApplication] Done — shutting down");
            System.exit(0);
        }
        log.info("[MongoArchiverApplication] Running in scheduled mode");
    }
}
