package com.archiver.util;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.index.IndexInfo;
import org.springframework.data.mongodb.core.index.IndexOperations;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@Slf4j
@RequiredArgsConstructor
public class IndexManager {

    private static final String INDEX_PREFIX = "_arch_tmp_";
    private final MongoTemplate mongoTemplate;
    private final Set<String> ownedIndexes = new LinkedHashSet<>();

    public void ensureIndex(String collection, String fieldPath) {
        try {
            IndexOperations indexOps = mongoTemplate.indexOps(collection);
            if (indexAlreadyExists(indexOps, fieldPath)) {
                log.info("[IndexManager] Pre-existing index on '{}.{}' — reusing", collection, fieldPath);
                return;
            }
            String indexName = INDEX_PREFIX + fieldPath.replace(".", "_");
            indexOps.ensureIndex(new Index().on(fieldPath, Sort.Direction.ASC).named(indexName));
            ownedIndexes.add(collection + "::" + indexName);
            log.info("[IndexManager] Created temporary index '{}' on '{}.{}'", indexName, collection, fieldPath);
        } catch (Exception e) {
            log.warn("[IndexManager] Could not ensure index on '{}.{}': {}", collection, fieldPath, e.getMessage());
        }
    }

    public void dropCreatedIndexes() {
        if (ownedIndexes.isEmpty()) return;
        log.info("[IndexManager] Dropping {} temporary index(es)...", ownedIndexes.size());
        for (String key : ownedIndexes) {
            String[] parts = key.split("::", 2);
            try {
                mongoTemplate.indexOps(parts[0]).dropIndex(parts[1]);
                log.info("[IndexManager] Dropped '{}' on '{}'", parts[1], parts[0]);
            } catch (Exception e) {
                log.warn("[IndexManager] Failed to drop '{}' on '{}': {}", parts[1], parts[0], e.getMessage());
            }
        }
        ownedIndexes.clear();
    }

    public int ownedCount() { return ownedIndexes.size(); }

    private boolean indexAlreadyExists(IndexOperations indexOps, String fieldPath) {
        try {
            List<IndexInfo> existing = indexOps.getIndexInfo();
            return existing.stream().anyMatch(info ->
                info.getIndexFields().stream().anyMatch(f -> f.getKey().equals(fieldPath)));
        } catch (Exception e) {
            log.warn("[IndexManager] Could not read index info: {}", e.getMessage());
            return false;
        }
    }
}
