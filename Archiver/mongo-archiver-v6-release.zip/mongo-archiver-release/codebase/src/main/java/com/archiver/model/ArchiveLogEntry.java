package com.archiver.model;

import lombok.Builder;
import lombok.Data;

import java.util.Date;
import java.util.Map;

@Data
@Builder
public class ArchiveLogEntry {

    public enum Status {
        SUCCESS, PARTIAL_FAILURE, FAILED, SKIPPED
    }

    public enum CollectionStatus {
        SUCCESS, FAILED, NO_DOCUMENTS, SKIPPED
    }

    private String jobName;
    private String entityId;
    private Status status;
    private Map<String, String> collections;
    private Date runAt;
}
