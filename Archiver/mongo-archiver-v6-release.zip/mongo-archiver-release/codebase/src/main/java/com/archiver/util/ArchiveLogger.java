package com.archiver.util;

import com.archiver.config.ArchiverProperties;
import com.archiver.model.ArchiveLogEntry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.CompoundIndexDefinition;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import java.util.Date;

@Slf4j
@Component
@RequiredArgsConstructor
public class ArchiveLogger {

    private final MongoTemplate mongoTemplate;
    private final ArchiverProperties properties;

    public void log(ArchiveLogEntry entry) {
        try {
            Query query = Query.query(
                Criteria.where("jobName").is(entry.getJobName())
                        .and("entityId").is(entry.getEntityId())
            );
            Update update = new Update()
                .set("status", entry.getStatus().name())
                .set("collections", entry.getCollections())
                .set("runAt", new Date())
                .inc("retryCount", 1)
                .setOnInsert("createdAt", new Date());
            mongoTemplate.upsert(query, update, properties.getArchiveLogCollection());
        } catch (Exception e) {
            log.warn("[ArchiveLogger] Failed to write log for entity={}: {}",
                entry.getEntityId(), e.getMessage());
        }
    }

    public void ensureIndexes() {
        try {
            String col = properties.getArchiveLogCollection();
            mongoTemplate.indexOps(col).ensureIndex(
                new CompoundIndexDefinition(
                    new Document("jobName", 1).append("entityId", 1)
                ).unique()
            );
            mongoTemplate.indexOps(col).ensureIndex(
                new CompoundIndexDefinition(new Document("status", 1).append("jobName", 1))
            );
            mongoTemplate.indexOps(col).ensureIndex(new Index("runAt", Sort.Direction.DESC));
            log.info("[ArchiveLogger] Indexes ensured on '{}'", col);
        } catch (Exception e) {
            log.warn("[ArchiveLogger] Index creation warning: {}", e.getMessage());
        }
    }
}
