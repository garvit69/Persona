package com.archiver.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Data
@Component
@ConfigurationProperties(prefix = "archiver")
public class ArchiverProperties {

    private String schedule = "0 0 2 * * ?";
    private String timezone = "UTC";
    private String archiveLogCollection = "archiveLog";
    private List<JobProperties> jobs;

    @Data
    public static class JobProperties {
        private String name;
        private int batchSize = 100;
        private AnchorProperties anchor;
        private List<RelatedProperties> related;
    }

    @Data
    public static class AnchorProperties {
        private String collection;
        private String idField;
        private String createdTsField;
        private int archiveAfterDays;
        private boolean deleteAfterArchive = true;
        private String archiveCollection;
    }

    @Data
    public static class RelatedProperties {
        private String collection;
        private String idPath;
        private boolean deleteAfterArchive = true;
        private String archiveCollection;
    }
}
