package com.archiver.core;

import com.archiver.config.ArchiverProperties;
import com.archiver.config.ArchiverProperties.AnchorProperties;
import com.archiver.config.ArchiverProperties.JobProperties;
import com.archiver.model.BackfillState;
import com.archiver.model.BackfillState.Status;
import com.archiver.util.ArchiveLogger;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * BackfillService
 *
 * <p>Runs on application startup (before the scheduler begins).
 * For each configured job, checks whether a backfill is needed and
 * processes monthly slices from the oldest record up to the archive cutoff.
 *
 * <h3>State machine per job</h3>
 * <pre>
 *   No state in DB    → fresh install, check if backfill needed
 *   IN_PROGRESS       → resume from lastCompletedSliceEnd (restart recovery)
 *   COMPLETED         → skip, go straight to scheduler
 * </pre>
 *
 * <h3>Resume on restart</h3>
 * <p>After each slice completes, {@link BackfillStateRepository#markSliceCompleted}
 * persists the resume point. If the app restarts mid-backfill, it picks up
 * from the last completed slice — not from the beginning.
 *
 * <h3>Backfill detection</h3>
 * <p>Queries the anchor collection for its oldest record. If that date is
 * older than {@code now - archiveAfterDays}, a backfill is needed.
 * If the anchor collection is empty or all records are within the retention
 * window, backfill is skipped.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class BackfillService {

    private final ArchiverProperties properties;
    private final MongoTemplate mongoTemplate;
    private final ArchiveLogger archiveLogger;
    private final BackfillStateRepository stateRepository;

    /**
     * Entry point — called from {@link com.archiver.job.ArchiveCronJob} on startup.
     * Processes all configured jobs sequentially.
     */
    public void runBackfillIfNeeded() {
        stateRepository.ensureIndexes();

        for (JobProperties jobConfig : properties.getJobs()) {
            try {
                processJob(jobConfig);
            } catch (Exception e) {
                log.error("[BackfillService:{}] Backfill failed: {}",
                    jobConfig.getName(), e.getMessage(), e);
            }
        }
    }

    // ─── Per-job backfill ─────────────────────────────────────────────────────

    private void processJob(JobProperties jobConfig) {
        String jobName = jobConfig.getName();
        BackfillState state = stateRepository.load(jobName);

        // ── Already completed — skip ──────────────────────────────────────────
        if (state != null && state.getStatus() == Status.COMPLETED) {
            log.info("[BackfillService:{}] Backfill already completed — skipping", jobName);
            return;
        }

        // ── Resuming an interrupted backfill ──────────────────────────────────
        if (state != null && state.getStatus() == Status.IN_PROGRESS) {
            log.info("[BackfillService:{}] Resuming interrupted backfill from {}",
                jobName, state.getLastCompletedSliceEnd());
            runSlices(jobConfig, state);
            return;
        }

        // ── Fresh start — check if backfill is needed ─────────────────────────
        Date cutoff = getCutoffDate(jobConfig.getAnchor().getArchiveAfterDays());
        Date oldestRecord = findOldestRecordDate(jobConfig.getAnchor());

        if (oldestRecord == null) {
            log.info("[BackfillService:{}] Anchor collection is empty — no backfill needed", jobName);
            return;
        }

        if (!oldestRecord.before(cutoff)) {
            log.info("[BackfillService:{}] Oldest record ({}) is within retention window — no backfill needed",
                jobName, oldestRecord);
            return;
        }

        // ── Calculate slices and persist initial state ────────────────────────
        Date fromDate = floorToMonthStart(oldestRecord);
        Date toDate   = floorToMonthStart(cutoff);
        int totalSlices = countMonthsBetween(fromDate, toDate);

        log.info("[BackfillService:{}] Backfill needed — {} monthly slices from {} to {}",
            jobName, totalSlices, fromDate, toDate);

        state = BackfillState.builder()
            .jobName(jobName)
            .status(Status.IN_PROGRESS)
            .backfillFromDate(fromDate)
            .backfillToDate(toDate)
            .totalSlices(totalSlices)
            .completedSlices(0)
            .startedAt(new Date())
            .build();

        stateRepository.saveInitial(state);
        runSlices(jobConfig, state);
    }

    // ─── Slice execution ──────────────────────────────────────────────────────

    /**
     * Execute monthly slices from the resume point to backfillToDate.
     * Each completed slice is persisted before moving to the next.
     */
    private void runSlices(JobProperties jobConfig, BackfillState state) {
        String jobName = jobConfig.getName();

        // Resume from lastCompletedSliceEnd if set, otherwise from beginning
        Date sliceStart = state.getLastCompletedSliceEnd() != null
            ? state.getLastCompletedSliceEnd()
            : state.getBackfillFromDate();

        Date backfillEnd = state.getBackfillToDate();
        int completedSlices = state.getCompletedSlices();
        int totalSlices = state.getTotalSlices();

        while (sliceStart.before(backfillEnd)) {
            Date sliceEnd = addOneMonth(sliceStart);
            if (sliceEnd.after(backfillEnd)) sliceEnd = backfillEnd;

            log.info("[BackfillService:{}] Slice {}/{} — {} to {}",
                jobName, completedSlices + 1, totalSlices, sliceStart, sliceEnd);

            // Run Archiver for this date slice
            Archiver archiver = new Archiver(jobConfig, mongoTemplate, archiveLogger);
            archiver.runForDateRange(sliceStart, sliceEnd);

            // Persist progress — this is the restart resume point
            completedSlices++;
            stateRepository.markSliceCompleted(jobName, sliceEnd, completedSlices);

            log.info("[BackfillService:{}] Slice {}/{} complete",
                jobName, completedSlices, totalSlices);

            sliceStart = sliceEnd;
        }

        stateRepository.markCompleted(jobName);
        log.info("[BackfillService:{}] All {} slices complete — backfill done", jobName, totalSlices);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    /**
     * Query the anchor collection for the oldest record's timestamp.
     * Returns null if the collection is empty.
     */
    private Date findOldestRecordDate(AnchorProperties anchor) {
        try {
            Query query = new Query()
                .with(org.springframework.data.domain.Sort.by(
                    org.springframework.data.domain.Sort.Direction.ASC,
                    anchor.getCreatedTsField()))
                .limit(1);
            query.fields().include(anchor.getCreatedTsField()).exclude("_id");

            Document doc = mongoTemplate.findOne(query, Document.class, anchor.getCollection());
            if (doc == null) return null;

            Object ts = doc.get(anchor.getCreatedTsField());
            if (ts instanceof Date) return (Date) ts;
            return null;
        } catch (Exception e) {
            log.error("[BackfillService] Failed to find oldest record in '{}': {}",
                anchor.getCollection(), e.getMessage(), e);
            return null;
        }
    }

    private Date getCutoffDate(int days) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -days);
        return cal.getTime();
    }

    /** Floor a date to the first day of its month at midnight. */
    private Date floorToMonthStart(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    private Date addOneMonth(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.MONTH, 1);
        return cal.getTime();
    }

    private int countMonthsBetween(Date from, Date to) {
        Calendar start = Calendar.getInstance();
        start.setTime(from);
        Calendar end = Calendar.getInstance();
        end.setTime(to);
        int months = 0;
        while (start.before(end)) {
            start.add(Calendar.MONTH, 1);
            months++;
        }
        return months;
    }
}
