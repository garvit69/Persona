package com.archiver.job;

import com.archiver.config.ArchiverProperties;
import com.archiver.core.Archiver;
import com.archiver.core.BackfillService;
import com.archiver.util.ArchiveLogger;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * ArchiveCronJob
 *
 * <p>On startup ({@link PostConstruct}):
 * <ol>
 *   <li>Ensures archiveLog indexes.</li>
 *   <li>Runs {@link BackfillService} — handles the initial backfill automatically,
 *       resuming from the last completed slice if the app was restarted mid-backfill.</li>
 * </ol>
 *
 * <p>After startup, runs on the configured cron schedule for daily incremental archival.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ArchiveCronJob {

    private final ArchiverProperties properties;
    private final MongoTemplate mongoTemplate;
    private final ArchiveLogger archiveLogger;
    private final BackfillService backfillService;

    private final AtomicBoolean running = new AtomicBoolean(false);

    @PostConstruct
    public void init() {
        archiveLogger.ensureIndexes();
        log.info("[ArchiveCronJob] Initialised. Schedule='{}' timezone='{}'",
            properties.getSchedule(), properties.getTimezone());
        log.info("[ArchiveCronJob] {} job(s) configured: {}",
            properties.getJobs().size(),
            properties.getJobs().stream().map(ArchiverProperties.JobProperties::getName).toList());

        // Run backfill on startup — no-op if already completed or not needed
        log.info("[ArchiveCronJob] Checking if backfill is needed...");
        backfillService.runBackfillIfNeeded();
        log.info("[ArchiveCronJob] Backfill check complete — scheduler is now active");
    }

    @Scheduled(cron = "${archiver.schedule}", zone = "${archiver.timezone}")
    public void runScheduled() {
        execute("scheduled");
    }

    public void runNow() {
        execute("manual");
    }

    private void execute(String trigger) {
        if (!running.compareAndSet(false, true)) {
            log.warn("[ArchiveCronJob] Previous run still in progress — skipping {} trigger", trigger);
            return;
        }
        long start = System.currentTimeMillis();
        log.info("[ArchiveCronJob] Run started at {} (trigger: {})", Instant.now(), trigger);
        try {
            for (ArchiverProperties.JobProperties jobConfig : properties.getJobs()) {
                try {
                    new Archiver(jobConfig, mongoTemplate, archiveLogger).run();
                } catch (Exception e) {
                    log.error("[ArchiveCronJob] Unhandled error in job '{}': {}",
                        jobConfig.getName(), e.getMessage(), e);
                }
            }
        } finally {
            running.set(false);
            log.info("[ArchiveCronJob] Completed in {}s",
                String.format("%.1f", (System.currentTimeMillis() - start) / 1000.0));
        }
    }
}
