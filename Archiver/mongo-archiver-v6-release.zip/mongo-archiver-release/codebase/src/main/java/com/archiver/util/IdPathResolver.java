package com.archiver.util;

import org.bson.Document;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.util.Date;
import java.util.List;

public final class IdPathResolver {

    private IdPathResolver() {}

    public static Object resolveValue(Document doc, String path) {
        String[] parts = path.split("\\.");
        Object current = doc;
        for (String part : parts) {
            if (!(current instanceof Document nested)) return null;
            current = nested.get(part);
        }
        return current;
    }

    public static Query buildSingleQuery(String idPath, Object idValue) {
        return Query.query(Criteria.where(idPath).is(idValue));
    }

    public static Query buildBatchQuery(String idPath, List<?> idValues) {
        return Query.query(Criteria.where(idPath).in(idValues));
    }

    /** Scheduled mode: createdTsField < cutoff */
    public static Query buildCutoffQuery(String tsField, Date cutoff) {
        return Query.query(Criteria.where(tsField).lt(cutoff));
    }

    /** Backfill mode: createdTsField >= fromDate AND createdTsField < toDate */
    public static Query buildDateRangeQuery(String tsField, Date fromDate, Date toDate) {
        return Query.query(Criteria.where(tsField).gte(fromDate).lt(toDate));
    }

    public static String extractIdAsString(Document doc, String field) {
        Object value = doc.get(field);
        return value != null ? value.toString() : null;
    }
}
