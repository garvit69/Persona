package com.archiver.core;

import com.archiver.config.ArchiverProperties;
import com.archiver.config.ArchiverProperties.AnchorProperties;
import com.archiver.config.ArchiverProperties.JobProperties;
import com.archiver.config.ArchiverProperties.RelatedProperties;
import com.archiver.model.ArchiveLogEntry;
import com.archiver.model.ArchiveLogEntry.CollectionStatus;
import com.archiver.model.ArchiveLogEntry.Status;
import com.archiver.util.ArchiveLogger;
import com.archiver.util.IdPathResolver;
import com.archiver.util.IndexManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.util.*;

/**
 * Archiver
 *
 * <p>Core archive engine for one configured job. Used by both:
 * <ul>
 *   <li>{@link ArchiveCronJob} — daily scheduled runs via {@link #run()}</li>
 *   <li>{@link BackfillService} — startup backfill slices via {@link #runForDateRange(Date, Date)}</li>
 * </ul>
 *
 * <h3>Query modes</h3>
 * <ul>
 *   <li>{@link #run()} — uses {@code archiveAfterDays} rolling cutoff</li>
 *   <li>{@link #runForDateRange(Date, Date)} — uses explicit from/to date range</li>
 * </ul>
 */
@Slf4j
@RequiredArgsConstructor
public class Archiver {

    private final JobProperties jobConfig;
    private final MongoTemplate mongoTemplate;
    private final ArchiveLogger archiveLogger;

    // ─── Entry points ─────────────────────────────────────────────────────────

    /**
     * Scheduled run — archive everything older than {@code archiveAfterDays}.
     */
    public void run() {
        Date cutoff = getCutoffDate(jobConfig.getAnchor().getArchiveAfterDays());
        log.info("[Archiver:{}] SCHEDULED run — archiving records with {} < {}",
            jobConfig.getName(), jobConfig.getAnchor().getCreatedTsField(), cutoff);
        executeWithQuery(IdPathResolver.buildCutoffQuery(
            jobConfig.getAnchor().getCreatedTsField(), cutoff));
    }

    /**
     * Backfill run — archive a specific date slice.
     * Called by {@link BackfillService} for each monthly chunk.
     *
     * @param fromDate lower bound (inclusive)
     * @param toDate   upper bound (exclusive)
     */
    public void runForDateRange(Date fromDate, Date toDate) {
        log.info("[Archiver:{}] BACKFILL run — archiving records {} >= {} AND < {}",
            jobConfig.getName(), jobConfig.getAnchor().getCreatedTsField(), fromDate, toDate);
        executeWithQuery(IdPathResolver.buildDateRangeQuery(
            jobConfig.getAnchor().getCreatedTsField(), fromDate, toDate));
    }

    // ─── Core execution ───────────────────────────────────────────────────────

    private void executeWithQuery(Query anchorQuery) {
        String jobName = jobConfig.getName();
        IndexManager indexManager = new IndexManager(mongoTemplate);

        try {
            ensureIndexes(indexManager);

            List<String> ids = fetchAnchorIds(anchorQuery);
            if (ids.isEmpty()) {
                log.info("[Archiver:{}] No records to archive", jobName);
                return;
            }

            log.info("[Archiver:{}] {} entities to process", jobName, ids.size());

            int batchSize = jobConfig.getBatchSize();
            int totalBatches = (int) Math.ceil((double) ids.size() / batchSize);

            for (int i = 0; i < ids.size(); i += batchSize) {
                List<String> batch = ids.subList(i, Math.min(i + batchSize, ids.size()));
                log.info("[Archiver:{}] Batch {}/{} ({} IDs)",
                    jobName, (i / batchSize) + 1, totalBatches, batch.size());
                processBatch(batch);
            }

        } finally {
            indexManager.dropCreatedIndexes();
        }
    }

    // ─── Index management ─────────────────────────────────────────────────────

    private void ensureIndexes(IndexManager indexManager) {
        AnchorProperties anchor = jobConfig.getAnchor();
        indexManager.ensureIndex(anchor.getCollection(), anchor.getCreatedTsField());
        indexManager.ensureIndex(anchor.getCollection(), anchor.getIdField());
        for (RelatedProperties rel : jobConfig.getRelated()) {
            indexManager.ensureIndex(rel.getCollection(), rel.getIdPath());
        }
        log.info("[Archiver:{}] Index check complete — {} temporary index(es) created",
            jobConfig.getName(), indexManager.ownedCount());
    }

    // ─── Anchor ID fetching ───────────────────────────────────────────────────

    private List<String> fetchAnchorIds(Query query) {
        AnchorProperties anchor = jobConfig.getAnchor();
        try {
            query.fields().include(anchor.getIdField()).exclude("_id");
            Set<String> ids = new LinkedHashSet<>();
            mongoTemplate.find(query, Document.class, anchor.getCollection())
                .forEach(doc -> {
                    String id = IdPathResolver.extractIdAsString(doc, anchor.getIdField());
                    if (id != null) ids.add(id);
                });
            log.info("[Archiver:{}] Found {} anchor IDs", jobConfig.getName(), ids.size());
            return new ArrayList<>(ids);
        } catch (Exception e) {
            log.error("[Archiver:{}] Failed to fetch anchor IDs: {}",
                jobConfig.getName(), e.getMessage(), e);
            return List.of();
        }
    }

    // ─── Batch & entity processing ────────────────────────────────────────────

    private void processBatch(List<String> entityIds) {
        for (String entityId : entityIds) {
            processEntity(entityId);
        }
    }

    private void processEntity(String entityId) {
        Map<String, String> collectionResults = new LinkedHashMap<>();

        boolean allRelatedSucceeded = true;
        for (RelatedProperties rel : jobConfig.getRelated()) {
            CollectionStatus result = archiveCollection(
                entityId, rel.getCollection(), rel.getIdPath(),
                rel.getArchiveCollection(), rel.isDeleteAfterArchive()
            );
            collectionResults.put(rel.getCollection(), result.name());
            if (result == CollectionStatus.FAILED) allRelatedSucceeded = false;
        }

        AnchorProperties anchor = jobConfig.getAnchor();
        if (allRelatedSucceeded) {
            CollectionStatus anchorResult = archiveCollection(
                entityId, anchor.getCollection(), anchor.getIdField(),
                anchor.getArchiveCollection(), anchor.isDeleteAfterArchive()
            );
            collectionResults.put(anchor.getCollection(), anchorResult.name());
        } else {
            collectionResults.put(anchor.getCollection(), CollectionStatus.SKIPPED.name());
            log.warn("[Archiver:{}] Anchor skipped for entity '{}' — related failure.",
                jobConfig.getName(), entityId);
        }

        archiveLogger.log(ArchiveLogEntry.builder()
            .jobName(jobConfig.getName())
            .entityId(entityId)
            .status(deriveOverallStatus(collectionResults))
            .collections(collectionResults)
            .runAt(new Date())
            .build());
    }

    // ─── Status derivation ────────────────────────────────────────────────────

    private Status deriveOverallStatus(Map<String, String> results) {
        long failed  = results.values().stream().filter(s -> s.equals(CollectionStatus.FAILED.name())).count();
        long skipped = results.values().stream().filter(s -> s.equals(CollectionStatus.SKIPPED.name())).count();
        if (skipped > 0)              return Status.PARTIAL_FAILURE;
        if (failed == results.size()) return Status.FAILED;
        if (failed > 0)               return Status.PARTIAL_FAILURE;
        return Status.SUCCESS;
    }

    // ─── Core archive operation ───────────────────────────────────────────────

    private CollectionStatus archiveCollection(
        String entityId, String srcCollection, String idPath,
        String archiveCollection, boolean deleteAfterArchive
    ) {
        String jobName = jobConfig.getName();
        try {
            Query query = IdPathResolver.buildSingleQuery(idPath, entityId);
            List<Document> docs = mongoTemplate.find(query, Document.class, srcCollection);

            if (docs.isEmpty()) {
                log.debug("[Archiver:{}] No documents in '{}' for entity '{}'",
                    jobName, srcCollection, entityId);
                return CollectionStatus.NO_DOCUMENTS;
            }

            Date archivedAt = new Date();
            docs.forEach(doc -> {
                doc.append("_archivedAt", archivedAt);
                doc.append("_archivedFrom", srcCollection);
            });

            bulkInsert(docs, archiveCollection, jobName, entityId, srcCollection);

            if (deleteAfterArchive) {
                mongoTemplate.remove(query, srcCollection);
            }

            log.info("[Archiver:{}] Archived {} doc(s): '{}' → '{}' (entity: '{}')",
                jobName, docs.size(), srcCollection, archiveCollection, entityId);

            return CollectionStatus.SUCCESS;

        } catch (Exception e) {
            log.error("[Archiver:{}] FAILED '{}' for entity '{}': {}",
                jobName, srcCollection, entityId, e.getMessage(), e);
            return CollectionStatus.FAILED;
        }
    }

    // ─── Bulk insert ──────────────────────────────────────────────────────────

    private void bulkInsert(List<Document> docs, String collection,
                            String jobName, String entityId, String srcCollection) {
        try {
            BulkOperations bulk = mongoTemplate.bulkOps(BulkOperations.BulkMode.UNORDERED, collection);
            docs.forEach(bulk::insert);
            bulk.execute();
        } catch (org.springframework.data.mongodb.BulkOperationException e) {
            int inserted = e.getResult() != null ? e.getResult().getInsertedCount() : 0;
            int dupes = docs.size() - inserted;
            if (dupes > 0) {
                log.warn("[Archiver:{}] '{}' entity='{}' — {} already archived, {} newly inserted",
                    jobName, srcCollection, entityId, dupes, inserted);
            }
        }
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private Date getCutoffDate(int days) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -days);
        return cal.getTime();
    }
}
