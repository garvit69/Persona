package com.archiver.core;

import com.archiver.model.BackfillState;
import com.archiver.model.BackfillState.Status;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * BackfillStateRepository
 *
 * <p>Reads and writes the {@code backfillState} collection — one document per job.
 * Provides the resume-on-restart guarantee: if the app crashes mid-backfill,
 * the next startup picks up from {@code lastCompletedSliceEnd}.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class BackfillStateRepository {

    static final String COLLECTION = "backfillState";

    private final MongoTemplate mongoTemplate;

    // ─── Reads ────────────────────────────────────────────────────────────────

    /**
     * Load persisted backfill state for a job.
     * Returns {@code null} if no state exists yet (fresh install).
     */
    public BackfillState load(String jobName) {
        return mongoTemplate.findOne(
            Query.query(Criteria.where("jobName").is(jobName)),
            BackfillState.class,
            COLLECTION
        );
    }

    // ─── Writes ───────────────────────────────────────────────────────────────

    /**
     * Persist initial state when a backfill begins for the first time.
     */
    public void saveInitial(BackfillState state) {
        mongoTemplate.upsert(
            Query.query(Criteria.where("jobName").is(state.getJobName())),
            new Update()
                .set("status", Status.IN_PROGRESS.name())
                .set("backfillFromDate", state.getBackfillFromDate())
                .set("backfillToDate", state.getBackfillToDate())
                .set("totalSlices", state.getTotalSlices())
                .set("completedSlices", 0)
                .set("lastCompletedSliceEnd", null)
                .set("startedAt", new Date())
                .set("completedAt", null),
            COLLECTION
        );
    }

    /**
     * Update progress after each successfully completed slice.
     * This is the resume point — on restart, backfill continues from here.
     */
    public void markSliceCompleted(String jobName, Date sliceEnd, int completedSlices) {
        mongoTemplate.updateFirst(
            Query.query(Criteria.where("jobName").is(jobName)),
            new Update()
                .set("lastCompletedSliceEnd", sliceEnd)
                .set("completedSlices", completedSlices),
            COLLECTION
        );
        log.info("[BackfillState:{}] Slice completed — progress saved (resumable at {})",
            jobName, sliceEnd);
    }

    /**
     * Mark the backfill as fully completed for this job.
     * Subsequent startups will skip backfill entirely.
     */
    public void markCompleted(String jobName) {
        mongoTemplate.updateFirst(
            Query.query(Criteria.where("jobName").is(jobName)),
            new Update()
                .set("status", Status.COMPLETED.name())
                .set("completedAt", new Date()),
            COLLECTION
        );
        log.info("[BackfillState:{}] Backfill marked COMPLETED", jobName);
    }

    /**
     * Ensure a unique index on jobName for fast lookups.
     */
    public void ensureIndexes() {
        try {
            mongoTemplate.indexOps(COLLECTION)
                .ensureIndex(new Index("jobName", Sort.Direction.ASC).unique());
        } catch (Exception e) {
            log.warn("[BackfillStateRepository] Index creation warning: {}", e.getMessage());
        }
    }
}
