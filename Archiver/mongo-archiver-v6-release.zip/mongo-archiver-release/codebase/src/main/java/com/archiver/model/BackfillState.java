package com.archiver.model;

import lombok.Builder;
import lombok.Data;

import java.util.Date;

/**
 * Persisted in the {@code backfillState} collection — one document per job.
 *
 * <p>Tracks backfill progress so a mid-run restart resumes from the last
 * completed slice rather than starting over from the beginning.
 *
 * <p>Document shape:
 * <pre>
 * {
 *   "jobName"               : "orders",
 *   "status"                : "NOT_STARTED | IN_PROGRESS | COMPLETED",
 *   "backfillFromDate"      : ISODate("2022-01-01"),  // oldest record found
 *   "backfillToDate"        : ISODate("2025-01-01"),  // cutoff = now - archiveAfterDays
 *   "lastCompletedSliceEnd" : ISODate("2022-08-01"),  // resume point on restart
 *   "totalSlices"           : 36,
 *   "completedSlices"       : 7,
 *   "startedAt"             : ISODate("..."),
 *   "completedAt"           : null | ISODate("...")
 * }
 * </pre>
 */
@Data
@Builder
public class BackfillState {

    public enum Status {
        NOT_STARTED,
        IN_PROGRESS,
        COMPLETED
    }

    private String jobName;
    private Status status;

    /** Oldest record date found in anchor collection — backfill starts here. */
    private Date backfillFromDate;

    /** now - archiveAfterDays — backfill ends here, scheduler takes over. */
    private Date backfillToDate;

    /**
     * End date of the last successfully completed slice.
     * On restart, backfill resumes from this date.
     * Null if no slice has completed yet.
     */
    private Date lastCompletedSliceEnd;

    private int totalSlices;
    private int completedSlices;
    private Date startedAt;
    private Date completedAt;
}
