# Mongo Archiver — Spring Boot (v6)

Automated, configurable MongoDB archiver with automatic backfill on startup and resume-on-restart capability.

## Files in this release

```
mongo-archiver-release/
├── README.md                    ← This file
├── MIGRATION_PLAN.txt           ← Step-by-step deployment & monitoring guide
├── DOCUMENTATION.txt            ← Complete technical documentation
├── flow_diagram.dot             ← Graphviz diagram source (create JPG with: dot -Tjpg flow_diagram.dot -o diagram.jpg)
└── codebase/                    ← Complete Spring Boot project
    ├── pom.xml
    ├── src/main/
    │   ├── resources/application.yml
    │   └── java/com/archiver/...
    └── [ready to build with Maven]
```

## Quick Start

### 1. Build

```bash
cd codebase
mvn clean package -DskipTests
```

Creates: `target/mongo-archiver-1.0.0.jar`

### 2. Deploy & Run

```bash
MONGO_URI=mongodb://your-host:27017 \
MONGO_DB=yourdb \
java -jar target/mongo-archiver-1.0.0.jar
```

**That's it.** The app will:
- Detect if a backfill is needed (oldest record vs retention window)
- Run monthly slices automatically
- Save progress after each slice (restart-safe)
- Hand over to the daily scheduler when done

### 3. Monitor

```javascript
db.backfillState.find().pretty()     // backfill progress
db.archiveLog.find({ status: { $in: ["FAILED","PARTIAL_FAILURE"] } })  // failures
```

## Key Features

✅ **Zero manual backfill steps** — automatic monthly slice processing
✅ **Resume-on-restart** — if the app crashes mid-backfill, next startup resumes from the last completed slice
✅ **Per-entity audit log** — one document per entity with all collection outcomes
✅ **Anchor-last strategy** — if any related collection fails, anchor stays in source for retry
✅ **Temporary index management** — auto-cleanup with guaranteed finally block execution
✅ **Configurable per entity** — just edit application.yml, no Java changes needed

## Configuration

Edit `codebase/src/main/resources/application.yml`:

- **schedule**: Cron expression for daily runs (default: 2 AM)
- **timezone**: Timezone for cron (default: UTC, change to `Asia/Kolkata` for IST)
- **archive-after-days**: Retention window in days (default: 180 = 6 months)
- **jobs**: List of entity types to archive (orders, invoices, sessions, etc.)

Each job has:
- **anchor**: The parent collection (orders, invoices, ...)
- **related**: Child collections that depend on the anchor via ID path (dot-notation support for nested fields)

## Documentation

### For deployment & monitoring:
→ Read `MIGRATION_PLAN.txt`

### For architecture & code details:
→ Read `DOCUMENTATION.txt`

### For visual flow:
```bash
# Generate JPG from graphviz source
dot -Tjpg flow_diagram.dot -o flow_diagram.jpg
```

## State Machines

### Per-Job Backfill State

```
Fresh install
   ↓
Check if backfill needed (oldest record vs retention window)
   ├─ YES → IN_PROGRESS
   │         ├─ Run monthly slices
   │         ├─ Save progress after each slice (resume-safe)
   │         └─ All done → COMPLETED
   └─ NO  → skip to daily scheduler
```

### Restart Safety

If the app restarts during backfill:
- Reads `lastCompletedSliceEnd` from `backfillState` collection
- Resumes from that slice, NOT from the beginning
- Continues running slices until all done

## Monitoring Queries

```javascript
// Backfill progress
db.backfillState.find({}, { jobName:1, status:1, completedSlices:1, totalSlices:1 })

// Archive failures
db.archiveLog.find({ status: { $in: ["FAILED","PARTIAL_FAILURE"] } })

// Which collections are failing
db.archiveLog.find({ "collections.orderPayments": "FAILED" }, { entityId:1 })

// Delete backfillState to restart from scratch
db.backfillState.deleteOne({ jobName: "orders" })
```

## Support

For detailed step-by-step instructions, troubleshooting, and monitoring guide:
→ See `MIGRATION_PLAN.txt`

For complete architecture, code walkthrough, and design decisions:
→ See `DOCUMENTATION.txt`
